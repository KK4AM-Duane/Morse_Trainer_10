#include "MorseWebSocket.h"
#include "MorseLookup.h"
#include "MorsePlayback.h"
#include "MorseCommands.h"
#include "MorseWebServer.h"
#include "KochTrainer.h"
#include "WiFiAPMode.h"
#include "WiFiStation.h"
#include "Storage.h"
#include "config.h"
#include "KeyInput.h"
#include "EchoTrainer.h"
#include "CWKeyerMode.h"
#include "PracticePlayer.h"
#include <ESPmDNS.h>

// --- Pin definitions ---
const unsigned int LED_PIN = 2;
const unsigned int BUZZER_PIN = 25;
const unsigned int LED_GREEN_PIN = 4;
const unsigned int LED_RED_PIN = 17;
const unsigned int KEY_PIN = 32;           // dit paddle / straight key
const unsigned int PADDLE_DAH_PIN = 33;    // dah paddle (iambic)
const unsigned int MODE_SWITCH_PIN = 18;   // HIGH = Trainer, LOW = CW Keyer
const unsigned int WIFI_MODE_PIN = 19;     // HIGH = AP mode,  LOW = STA mode (phone hotspot)
const unsigned int TX_KEY_PIN = 23;        // output to external transmitter relay
const int PWM_DUTY_CYCLE = 128;

// --- IP Blink Feature (STA mode only) ---
const unsigned int IP_BLINK_SWITCH_PIN = 15;  // Switch to ground to trigger IP/NC blink
const unsigned int EXTERNAL_LED_PIN = 16;     // External LED for IP address display

// --- RNG seed pin (floating ADC for entropy) ---
static const int RAND_PIN = 36;

// --- mDNS hostname (http://cwtrainer.local) ---
static const char* MDNS_HOSTNAME = "cwtrainer";

// --- Morse timing at 10 WPM for IP blink (1 dit = 120ms) ---
#define IP_DIT_DURATION 120
#define IP_DAH_DURATION (3 * IP_DIT_DURATION)
#define IP_SYMBOL_SPACE IP_DIT_DURATION
#define IP_LETTER_SPACE (3 * IP_DIT_DURATION)
#define IP_WORD_SPACE (7 * IP_DIT_DURATION)

// Morse code for digits 0-9
const char* MORSE_DIGITS[] = {
  "-----",  // 0
  ".----",  // 1
  "..---",  // 2
  "...--",  // 3
  "....-",  // 4
  ".....",  // 5
  "-....",  // 6
  "--...",  // 7
  "---..",  // 8
  "----."   // 9
};

// Morse code for letters N and C
const char* MORSE_N = "-.";
const char* MORSE_C = "-.-.";
const char* MORSE_PERIOD = ".-.-.-";  // Period (for IP address dots)

// --- Function prototypes for IP blinking ---
void blinkMorseCode(const char* morseCode);
void blinkIPAddress();
void blinkNC();
void checkIPBlinkSwitch();

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n======================================");
  Serial.println("   ESP32 Morse Code Trainer");
  Serial.println("======================================\n");

  // Seed the random number generator from a floating ADC pin
  randomSeed(analogRead(RAND_PIN));

  // Initialize hardware pins
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(LED_GREEN_PIN, OUTPUT);
  digitalWrite(LED_GREEN_PIN, LOW);

  pinMode(LED_RED_PIN, OUTPUT);
  digitalWrite(LED_RED_PIN, LOW);

  pinMode(KEY_PIN, INPUT_PULLUP);          // dit paddle / straight key
  pinMode(PADDLE_DAH_PIN, INPUT_PULLUP);   // dah paddle (iambic)
  pinMode(MODE_SWITCH_PIN, INPUT_PULLUP);  // mode switch: HIGH=Trainer
  pinMode(WIFI_MODE_PIN, INPUT_PULLUP);    // WiFi switch: HIGH=AP, LOW=STA
  pinMode(TX_KEY_PIN, OUTPUT);             // TX keying relay output
  digitalWrite(TX_KEY_PIN, LOW);

  // Initialize IP blink feature pins
  pinMode(IP_BLINK_SWITCH_PIN, INPUT_PULLUP);  // Switch to ground to trigger
  pinMode(EXTERNAL_LED_PIN, OUTPUT);
  digitalWrite(EXTERNAL_LED_PIN, LOW);

  // Configure buzzer PWM using LEDC
  ledcAttach(BUZZER_PIN, 800, 8);  // 800 Hz tone, 8-bit resolution
  ledcWrite(BUZZER_PIN, 0);

  // Initialize Morse code lookup table
  initializeVectorTable();

  // Initialize NVS storage (must be before anything that loads state)
  initStorage();

  // Now safe to load saved settings from NVS
  initKeyInput();              // loads key type (Straight/Iambic) from NVS
  initEchoTrainer();           // loads echo char source (Koch/Full) from NVS
  initCWKeyerMode();           // reads mode switch, sets initial operating mode

  // Initialize Koch trainer (loads lesson + charStats + WPM from NVS)
  initKochTrainer();

  // Update timing from loaded WPM
  updateTiming();

  // Restore buzzer mute state from NVS
  setBuzzerEnabled(loadBuzzerFromNVS());

  // Initialize practice player (no NVS state   just zeroes)
  initPracticePlayer();

  // -- WiFi mode selection (read hardware switch before starting WiFi) --
  int wifiSwitch = digitalRead(WIFI_MODE_PIN);
  if (wifiSwitch == LOW) {
    // Switch closed to GND ? Station mode (connect to phone hotspot)
    setWiFiOpMode(WiFiOpMode::STA);
    Serial.println("WiFi switch: STA (phone hotspot)");
    initWiFiSTA();
  } else {
    // Switch open (pulled HIGH) ? AP mode (current default behavior)
    setWiFiOpMode(WiFiOpMode::AP);
    Serial.println("WiFi switch: AP (ESP32 network)");
    initWiFiAP();
  }

  // -- mDNS: advertise http://cwtrainer.local on either interface --
  if (MDNS.begin(MDNS_HOSTNAME)) {
    MDNS.addService("http", "tcp", 80);
    Serial.printf("✓ mDNS responder started: http://%s.local\n", MDNS_HOSTNAME);
  } else {
    Serial.println("✗ mDNS failed to start");
  }

  // Start web server (includes WebSocket)   works on either WiFi interface
  initWebServer();

  // Show the help menu on startup so the user sees available commands
  showHelp();

  Serial.println("Ready! Type 'help' for commands.\n");
  Serial.print("> ");
}

void loop() {
  // Process serial commands
  readSerialInput();

  // Poll hardware mode switch + run CW keyer passthrough if active
  pollModeSwitch();

  // Update non-blocking Morse playback state machine
  updatePlayback();

  // Poll key input for trainer mode (straight key or iambic echo decode)
  // Skip when in CW Keyer mode   pollModeSwitch handles key input there
  if (!isCWKeyerMode()) {
    pollKeyInput();
  }

  // Update Echo trainer state machine
  updateEchoTrainer();

  // Update Koch trainer state machine (no-op when idle)
  updateKochTrainer();

  // Update Practice player (feeds words to playback engine)
  updatePracticePlayer();

  // Monitor WiFi connections (mode-specific)
  if (getWiFiOpMode() == WiFiOpMode::AP) {
    checkWiFiClients();
    blinkLEDForConnection();
  } else {
    checkWiFiSTA();
    // Check IP blink switch (STA mode only)
    checkIPBlinkSwitch();
  }

  // Handle web server (WebSocket cleanup)
  handleWebServer();
}

// ═══════════════════════════════════════════════════════════════════
// IP Address Blinking Functions (STA mode only)
// ═══════════════════════════════════════════════════════════════════

/**
 * Check if IP blink switch is pressed (LOW).
 * Blinks REPEATEDLY while switch remains grounded:
 *   - IP address (if connected to WiFi)
 *   - "NC" (if not connected)
 */
void checkIPBlinkSwitch() {
  // Check if switch is pressed (LOW)
  if (digitalRead(IP_BLINK_SWITCH_PIN) == LOW) {
    delay(50);  // Debounce
    
    // Confirm still pressed after debounce
    if (digitalRead(IP_BLINK_SWITCH_PIN) == LOW) {
      
      // Blink repeatedly while switch is held down
      while (digitalRead(IP_BLINK_SWITCH_PIN) == LOW) {
        if (isSTAReady()) {
          // Connected: blink IP address
          blinkIPAddress();
        } else {
          // Not connected: blink NC
          blinkNC();
        }
        
        // Check if switch is still pressed after blinking
        // (allows user to release during long blink sequence)
        if (digitalRead(IP_BLINK_SWITCH_PIN) == HIGH) {
          break;
        }
        
        // Short pause between repetitions
        delay(1000);
      }
      
      Serial.println("[IP Blink Stopped - Switch Released]\n");
      Serial.print("> ");
    }
  }
}

/**
 * Blink the IP address in Morse code at 10 WPM on both LEDs.
 * Example: 192.168.1.100 -> "1 9 2 . 1 6 8 . 1 . 1 0 0"
 */
void blinkIPAddress() {
  String ip = getSTAIPAddress();
  
  for (int i = 0; i < ip.length(); i++) {
    // Allow early exit if switch is released during blinking
    if (digitalRead(IP_BLINK_SWITCH_PIN) == HIGH) {
      return;
    }
    
    char c = ip[i];
    
    if (c == '.') {
      // Blink period (.-.-.-) with word space after
      blinkMorseCode(MORSE_PERIOD);
      delay(IP_WORD_SPACE);
    } 
    else if (isdigit(c)) {
      // Blink digit (0-9) with letter space after
      int digit = c - '0';
      blinkMorseCode(MORSE_DIGITS[digit]);
      delay(IP_LETTER_SPACE);
    }
  }
}

/**
 * Blink "NC" (Not Connected) in Morse code at 10 WPM.
 * Single iteration (called repeatedly by checkIPBlinkSwitch).
 */
void blinkNC() {
  // Allow early exit if switch is released
  if (digitalRead(IP_BLINK_SWITCH_PIN) == HIGH) {
    return;
  }
  
  blinkMorseCode(MORSE_N);
  delay(IP_LETTER_SPACE);
  
  if (digitalRead(IP_BLINK_SWITCH_PIN) == HIGH) {
    return;
  }
  
  blinkMorseCode(MORSE_C);
  delay(IP_WORD_SPACE);
}

/**
 * Blink a Morse code string on both LEDs (onboard + external).
 * @param morseCode String containing '.' (dit) and '-' (dah)
 */
void blinkMorseCode(const char* morseCode) {
  for (int i = 0; morseCode[i] != '\0'; i++) {
    // Allow early exit if switch is released
    if (digitalRead(IP_BLINK_SWITCH_PIN) == HIGH) {
      digitalWrite(LED_PIN, LOW);
      digitalWrite(EXTERNAL_LED_PIN, LOW);
      return;
    }
    
    // Turn both LEDs ON
    digitalWrite(LED_PIN, HIGH);
    digitalWrite(EXTERNAL_LED_PIN, HIGH);
    
    // Dit or Dah duration
    if (morseCode[i] == '.') {
      delay(IP_DIT_DURATION);
    } else if (morseCode[i] == '-') {
      delay(IP_DAH_DURATION);
    }
    
    // Turn both LEDs OFF
    digitalWrite(LED_PIN, LOW);
    digitalWrite(EXTERNAL_LED_PIN, LOW);
    
    // Space between symbols
    delay(IP_SYMBOL_SPACE);
  }
}