#include "MorseWebSocket.h"
#include "MorsePlayback.h"
#include "MorseLookup.h"
#include "MorseCommands.h"
#include "KochTrainer.h"
#include "WiFiAP.h"

// WebSocket endpoint lives at /ws
static AsyncWebSocket ws("/ws");

// ---------------- Internal helpers ----------------

// Build a JSON string for the active Koch characters.
// Returns e.g. ["K","M","U","R"] with prosign display names.
static String buildKochCharsJson() {
  int count = getKochActiveCount();
  String json = "[";
  for (int i = 0; i < count; i++) {
    if (i > 0) json += ',';
    char c = KOCH_ORDER_FULL[i];
    // Use display names for prosign symbols
    String display;
    if (c == '^')       display = "AR";
    else if (c == '[')  display = "BT";
    else if (c == '|')  display = "SK";
    else                display = String(c);
    json += "{\"ch\":\"";
    // Escape backslash and quote for valid JSON
    if (c == '\\')      json += "\\\\";
    else if (c == '"')  json += "\\\"";
    else                json += c;
    json += "\",\"display\":\"" + display + "\"}";
  }
  json += "]";
  return json;
}

// ---------------- Outbound: server → all clients ----------------

void wsBroadcastCharSent(char ch, const String &morse) {
  if (ws.count() == 0) return;

  String json = "{\"type\":\"char_sent\",\"char\":\"";
  // Escape backslash and quote for valid JSON
  if (ch == '\\')      json += "\\\\";
  else if (ch == '"')  json += "\\\"";
  else                 json += ch;
  json += "\",\"morse\":\"" + morse +
          "\",\"ditMs\":" + String(DOT_MS) +
          ",\"timestamp\":" + String(millis()) + "}";

  ws.textAll(json);
}

void wsBroadcastPlaybackStart(const String &message, unsigned int wpm) {
  if (ws.count() == 0) return;

  String json = "{\"type\":\"playback_start\",\"message\":\"" + message +
                "\",\"wpm\":" + String(wpm) + "}";
  ws.textAll(json);
}

void wsBroadcastPlaybackDone() {
  if (ws.count() == 0) return;
  ws.textAll("{\"type\":\"playback_done\"}");
}

void wsBroadcastSpeedChange(unsigned int wpm) {
  if (ws.count() == 0) return;

  String json = "{\"type\":\"speed_change\",\"wpm\":" + String(wpm) + "}";
  ws.textAll(json);
}

void wsBroadcastStatus() {
  if (ws.count() == 0) return;

  String modeStr;
  if (currentMode == MorseMode::Koch)             modeStr = "Koch";
  else if (currentMode == MorseMode::Progmem)     modeStr = "PROGMEM";
  else if (currentMode == MorseMode::Progtable)   modeStr = "PROGTABLE";
  else                                             modeStr = "Vector";

  String json = "{\"type\":\"status\""
                ",\"wpm\":" + String(WPM) +
                ",\"mode\":\"" + modeStr + "\""
                ",\"playing\":" + String(playback.state != PlaybackState::Idle ? "true" : "false") +
                ",\"koch_active\":" + String(isKochActive() ? "true" : "false") +
                ",\"koch_paused\":" + String(isKochPaused() ? "true" : "false") +
                ",\"koch_lesson\":" + String(getKochLesson()) +
                ",\"koch_chars\":" + buildKochCharsJson() +
                ",\"buzzer_enabled\":" + String(isBuzzerEnabled() ? "true" : "false") +
                ",\"stations\":" + String(getStationCount()) +
                ",\"uptime_ms\":" + String(millis()) +
                ",\"free_heap\":" + String(ESP.getFreeHeap()) +
                "}";
  ws.textAll(json);
}

// --- Freeform (WORD) playback broadcasts ---

void wsBroadcastWordChar(char ch, const String &pattern, unsigned int ditMs) {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"word_char\",\"char\":\"";
  if (ch == '\\')      json += "\\\\";
  else if (ch == '"')  json += "\\\"";
  else                 json += ch;
  json += "\",\"pattern\":\"" + pattern +
          "\",\"ditMs\":" + String(ditMs) + "}";
  ws.textAll(json);
}

void wsBroadcastWordGo() {
  if (ws.count() == 0) return;
  ws.textAll("{\"type\":\"word_go\"}");
}

// --- Koch trainer broadcasts ---

void wsBroadcastKochChallenge(uint8_t lesson, uint16_t questionNum,
                               const String &pattern, unsigned int ditMs) {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"koch_challenge\""
                ",\"lesson\":" + String(lesson) +
                ",\"question\":" + String(questionNum) +
                ",\"pattern\":\"" + pattern + "\""
                ",\"ditMs\":" + String(ditMs) +
                ",\"timestamp\":" + String(millis()) + "}";
  ws.textAll(json);
}

void wsBroadcastKochGo() {
  if (ws.count() == 0) return;
  ws.textAll("{\"type\":\"koch_go\"}");
}

void wsBroadcastKochResult(char expected, char received, bool correct,
                           unsigned long reactionMs,
                           uint16_t sessionCorrect, uint16_t sessionTotal,
                           uint8_t lesson) {
  if (ws.count() == 0) return;

  String json = "{\"type\":\"koch_result\""
                ",\"expected\":\"";
  if (expected == '\\')      json += "\\\\";
  else if (expected == '"')  json += "\\\"";
  else                       json += expected;
  json += "\",\"received\":\"";
  if (received == '\\')      json += "\\\\";
  else if (received == '"')  json += "\\\"";
  else                       json += received;
  json += "\",\"correct\":" + String(correct ? "true" : "false") +
          ",\"reaction_ms\":" + String(reactionMs) +
          ",\"session_correct\":" + String(sessionCorrect) +
          ",\"session_total\":" + String(sessionTotal) +
          ",\"lesson\":" + String(lesson) + "}";
  ws.textAll(json);
}

void wsBroadcastKochSession(bool started, uint8_t lesson, unsigned int wpm) {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"koch_session\""
                ",\"started\":" + String(started ? "true" : "false") +
                ",\"lesson\":" + String(lesson) +
                ",\"wpm\":" + String(wpm) + "}";
  ws.textAll(json);
}

void wsBroadcastKochEvent(const String &text) {
  if (ws.count() == 0) return;
  // Escape for JSON
  String escaped = text;
  escaped.replace("\\", "\\\\");
  escaped.replace("\"", "\\\"");
  String json = "{\"type\":\"koch_event\",\"message\":\"" + escaped + "\"}";
  ws.textAll(json);
}

void wsBroadcastKochChars() {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"koch_chars\""
                ",\"lesson\":" + String(getKochLesson()) +
                ",\"chars\":" + buildKochCharsJson() + "}";
  ws.textAll(json);
}

// ---------------- Inbound: client → server ----------------

// Simple JSON key extraction (avoids pulling in ArduinoJson for a few fields)
static String jsonGetString(const String &json, const String &key) {
  String search = "\"" + key + "\":\"";
  int start = json.indexOf(search);
  if (start < 0) return "";
  start += search.length();
  int end = json.indexOf('"', start);
  if (end < 0) return "";
  return json.substring(start, end);
}

static int jsonGetInt(const String &json, const String &key) {
  String search = "\"" + key + "\":";
  int start = json.indexOf(search);
  if (start < 0) return -1;
  start += search.length();
  // Skip whitespace
  while (start < (int)json.length() && json[start] == ' ') start++;
  int end = start;
  while (end < (int)json.length() && (isDigit(json[end]) || json[end] == '-')) end++;
  return json.substring(start, end).toInt();
}

static void handleIncomingMessage(AsyncWebSocketClient *client, const String &msg) {
  Serial.printf(">>> WS[%u]: %s\n", client->id(), msg.c_str());

  String type = jsonGetString(msg, "type");

  // --- Koch stop: highest priority, works unconditionally ---
  if (type == "koch_stop") {
    if (isKochActive()) {
      stopKochSession();
    }
    return;
  }

  // --- Koch ready: phone has prepared audio, handshake ACK ---
  if (type == "koch_ready") {
    kochPhoneReady();
    return;
  }

  // --- Word ready: phone has prepared audio for freeform char ---
  if (type == "word_ready") {
    wordPhoneReady();
    return;
  }

  if (type == "send") {
    // Client wants to transmit a message in morse
    String message = jsonGetString(msg, "message");
    message.toUpperCase();
    if (message.length() > 0 && playback.state == PlaybackState::Idle && !isKochActive()) {
      startTransmission(message);
    }
  }
  else if (type == "ping") {
    // Round-trip latency test — reply immediately to the requesting client
    String json = "{\"type\":\"pong\",\"uptime_ms\":" + String(millis()) + "}";
    client->text(json);
    Serial.println(">>> Pong sent");
  }
  else if (type == "chat") {
    // Echo the message back to ALL clients with a server timestamp
    String message = jsonGetString(msg, "message");
    if (message.length() > 0) {
      Serial.printf(">>> Chat from WS[%u]: %s\n", client->id(), message.c_str());

      // Escape quotes in the message for valid JSON
      message.replace("\\", "\\\\");
      message.replace("\"", "\\\"");

      String json = "{\"type\":\"chat_echo\",\"message\":\"" + message +
                    "\",\"from\":" + String(client->id()) +
                    ",\"timestamp\":" + String(millis()) + "}";
      ws.textAll(json);
    }
  }
  else if (type == "koch_answer") {
    // Student submitted an answer from the phone
    String ch = jsonGetString(msg, "char");
    if (ch.length() > 0 && isKochActive()) {
      kochSubmitAnswer(ch[0]);
    }
  }
  else if (type == "set_wpm") {
    int newWPM = jsonGetInt(msg, "wpm");
    if (newWPM >= 1 && newWPM <= 60) {
      setWPM(newWPM);
      wsBroadcastSpeedChange(WPM);
    }
  }
  else if (type == "set_buzzer") {
    String val = jsonGetString(msg, "enabled");
    bool en = (val == "true" || val == "1");
    setBuzzerEnabled(en);
    saveBuzzerToNVS();
    wsBroadcastBuzzerState(isBuzzerEnabled());
  }
  else if (type == "koch_pause") {
    if (isKochActive() && !isKochPaused()) {
      pauseKochSession();
    }
  }
  else if (type == "koch_resume") {
    if (isKochPaused()) {
      resumeKochSession();
    }
  }
  else if (type == "koch_reset") {
    // Reset all Koch progress to defaults
    resetKochProgress();
  }
  else if (type == "get_status") {
    // Send status only to the requesting client
    String modeStr;
    if (currentMode == MorseMode::Koch)             modeStr = "Koch";
    else if (currentMode == MorseMode::Progmem)     modeStr = "PROGMEM";
    else if (currentMode == MorseMode::Progtable)   modeStr = "PROGTABLE";
    else                                             modeStr = "Vector";

    String json = "{\"type\":\"status\""
                  ",\"wpm\":" + String(WPM) +
                  ",\"mode\":\"" + modeStr + "\""
                  ",\"playing\":" + String(playback.state != PlaybackState::Idle ? "true" : "false") +
                  ",\"koch_active\":" + String(isKochActive() ? "true" : "false") +
                  ",\"koch_paused\":" + String(isKochPaused() ? "true" : "false") +
                  ",\"koch_lesson\":" + String(getKochLesson()) +
                  ",\"koch_chars\":" + buildKochCharsJson() +
                  ",\"buzzer_enabled\":" + String(isBuzzerEnabled() ? "true" : "false") +
                  ",\"stations\":" + String(getStationCount()) +
                  ",\"uptime_ms\":" + String(millis()) +
                  ",\"free_heap\":" + String(ESP.getFreeHeap()) +
                  "}";
    client->text(json);
  }
  else if (type == "response") {
    // Training response from the user (for future scoring)
    String ch = jsonGetString(msg, "char");
    int reactionMs = jsonGetInt(msg, "reaction_ms");
    Serial.printf(">>> WS training response: '%s' in %d ms\n", ch.c_str(), reactionMs);
  }
  else if (type == "command") {
    // Pass an arbitrary serial command through the existing handler
    String cmd = jsonGetString(msg, "cmd");
    if (cmd.length() > 0) {
      processCommand(cmd);
    }
  }
  else {
    Serial.printf(">>> WS[%u]: unknown type '%s'\n", client->id(), type.c_str());
  }
}

// ---------------- WebSocket event dispatcher ----------------

static void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
                       AwsEventType type, void *arg, uint8_t *data, size_t len) {
  switch (type) {
    case WS_EVT_CONNECT:
      Serial.printf(">>> WS[%u] connected from %s\n", client->id(),
                     client->remoteIP().toString().c_str());
      {
        // Send a welcome + current state so the UI can hydrate immediately
        String welcome = "{\"type\":\"connected\",\"wpm\":" + String(WPM) +
                          ",\"koch_active\":" + String(isKochActive() ? "true" : "false") +
                          ",\"koch_paused\":" + String(isKochPaused() ? "true" : "false") +
                          ",\"koch_lesson\":" + String(getKochLesson()) +
                          ",\"koch_chars\":" + buildKochCharsJson() +
                          ",\"buzzer_enabled\":" + String(isBuzzerEnabled() ? "true" : "false") +
                          ",\"msg\":\"CW Trainer WebSocket ready\"}";
        client->text(welcome);
      }
      break;

    case WS_EVT_DISCONNECT:
      Serial.printf(">>> WS[%u] disconnected\n", client->id());
      break;

    case WS_EVT_DATA:
      {
        AwsFrameInfo *info = (AwsFrameInfo *)arg;
        if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
          // Complete text frame — the common case for small JSON messages
          String msg;
          msg.reserve(len);
          for (size_t i = 0; i < len; i++) {
            msg += (char)data[i];
          }
          handleIncomingMessage(client, msg);
        }
      }
      break;

    case WS_EVT_PONG:
      // Client responded to a ping — connection is alive
      break;

    case WS_EVT_ERROR:
      Serial.printf(">>> WS[%u] error(%u): %s\n", client->id(),
                     *((uint16_t *)arg), (char *)data);
      break;
  }
}

// ---------------- Public init / cleanup ----------------

void initWebSocket(AsyncWebServer &server) {
  ws.onEvent(onWsEvent);
  server.addHandler(&ws);
  Serial.println("✓ WebSocket handler registered at /ws");
}

void cleanupWebSocketClients() {
  // Prune dead connections periodically (call from loop)
  ws.cleanupClients();
}

void wsBroadcastBuzzerState(bool enabled) {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"buzzer_state\",\"enabled\":";
  json += enabled ? "true" : "false";
  json += "}";
  ws.textAll(json);
}

void wsBroadcastKochPause(bool paused) {
  if (ws.count() == 0) return;
  String json = "{\"type\":\"koch_pause\",\"paused\":";
  json += paused ? "true" : "false";
  json += "}";
  ws.textAll(json);
}