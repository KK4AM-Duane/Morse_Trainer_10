// ================================================================
//  CW Trainer — Phone Interface
//  Connects to ESP32 WebSocket at /ws
// ================================================================

'use strict';

// ── DOM refs ────────────────────────────────────────────────
var elConnStatus   = null;
var elHeaderLesson = null;
var elHeaderWpm    = null;
var elDisplayChar  = null;
var elDisplayMorse = null;
var elDisplayMsg   = null;
var elScoreCorrect = null;
var elScoreTotal   = null;
var elScorePct     = null;
var elScoreStreak  = null;
var elScoreReact   = null;
var elCharGrid     = null;
var elBtnStart     = null;
var elBtnPause     = null;
var elBtnStop      = null;
var elBtnReplay    = null;
var elBtnReset     = null;
var elBtnBuzzer    = null;
var elSpeedDisplay = null;
var elStatsBody    = null;
var elLogBody      = null;

function cacheDom() {
  elConnStatus   = document.getElementById('conn-status');
  elHeaderLesson = document.getElementById('header-lesson');
  elHeaderWpm    = document.getElementById('header-wpm');
  elDisplayChar  = document.getElementById('display-char');
  elDisplayMorse = document.getElementById('display-morse');
  elDisplayMsg   = document.getElementById('display-msg');
  elScoreCorrect = document.getElementById('score-correct');
  elScoreTotal   = document.getElementById('score-total');
  elScorePct     = document.getElementById('score-pct');
  elScoreStreak  = document.getElementById('score-streak');
  elScoreReact   = document.getElementById('score-reaction');
  elCharGrid     = document.getElementById('char-grid');
  elBtnStart     = document.getElementById('btn-start');
  elBtnPause     = document.getElementById('btn-pause');
  elBtnStop      = document.getElementById('btn-stop');
  elBtnReplay    = document.getElementById('btn-replay');
  elBtnReset     = document.getElementById('btn-reset');
  elBtnBuzzer    = document.getElementById('btn-buzzer');
  elSpeedDisplay = document.getElementById('speed-display');
  elStatsBody    = document.getElementById('stats-body');
  elLogBody      = document.getElementById('log-body');
}

// ── State ───────────────────────────────────────────────────
var ws            = null;
var kochActive    = false;
var currentWpm    = 20;
var currentLesson = 2;
var sessionCorrect = 0;
var sessionTotal   = 0;
var streak         = 0;
var inputEnabled   = false;
var lastPattern    = '';
var lastDitMs      = 60;
var buzzerEnabled  = true;
var kochPaused     = false;

// Pre-built audio sequence waiting for the "go" signal (Koch or WORD)
var pendingSeq     = null;

// Active Koch characters — populated from server via koch_chars messages.
// Each entry: { ch: 'K', display: 'K' } or { ch: '^', display: 'AR' }
var activeKochChars = [];

// Fallback Koch order used only until the server sends the real list
var KOCH_ORDER_FALLBACK = 'KMURESNAPTLWI.JZ=FOY,VG5/Q92H38B?47C1D60X';
var KOCH_PROSIGNS_FALLBACK = [
  { idx: 44, ch: '^', display: 'AR' },
  { idx: 45, ch: '[', display: 'BT' },
  { idx: 46, ch: '|', display: 'SK' }
];

// Server-side per-character stats (fetched from /api/koch_stats)
var serverStats = null;

// ── WebSocket ───────────────────────────────────────────────
function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  updateConnStatus('connecting');
  ws = new WebSocket('ws://' + location.host + '/ws');

  ws.onopen = function () {
    updateConnStatus('connected');
    // Request full status on connect
    wsSend({ type: 'get_status' });
    logEvent('Connected to trainer');
  };

  ws.onclose = function () {
    updateConnStatus('disconnected');
    setTimeout(connect, 2000);
  };

  ws.onerror = function () {
    updateConnStatus('disconnected');
  };

  ws.onmessage = function (evt) {
    var msg;
    try { msg = JSON.parse(evt.data); } catch (e) { return; }
    handleMessage(msg);
  };
}

function wsSend(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(obj));
  }
}

function updateConnStatus(state) {
  if (!elConnStatus) return;
  elConnStatus.className = 'status ' + state;
  if (state === 'connected')    elConnStatus.innerHTML = '● Online';
  else if (state === 'connecting') elConnStatus.innerHTML = '● Connecting…';
  else                           elConnStatus.innerHTML = '● Offline';
}

// ── Message Router ──────────────────────────────────────────
function handleMessage(msg) {
  switch (msg.type) {

    // ── Connection welcome (sent on WS connect) ──
    case 'connected':
      currentWpm    = msg.wpm || currentWpm;
      currentLesson = msg.koch_lesson || currentLesson;
      kochActive    = !!msg.koch_active;
      kochPaused    = !!msg.koch_paused;
      if (msg.buzzer_enabled !== undefined) { buzzerEnabled = !!msg.buzzer_enabled; }
      if (msg.koch_chars) {
        applyKochChars(msg.koch_chars, msg.koch_lesson);
      }
      updateWpmDisplay();
      updateLessonDisplay();
      updateControlButtons();
      updateBuzzerButton();
      break;

    // ── Full status response ──
    case 'status':
      currentWpm    = msg.wpm || currentWpm;
      currentLesson = msg.koch_lesson || currentLesson;
      kochActive    = !!msg.koch_active;
      kochPaused    = !!msg.koch_paused;
      if (msg.buzzer_enabled !== undefined) { buzzerEnabled = !!msg.buzzer_enabled; }
      if (msg.koch_chars) {
        applyKochChars(msg.koch_chars, msg.koch_lesson);
      } else {
        buildCharGridFallback();
      }
      updateWpmDisplay();
      updateLessonDisplay();
      updateControlButtons();
      updateBuzzerButton();
      break;

    // ── Server-authoritative Koch character list ──
    case 'koch_chars':
      applyKochChars(msg.chars, msg.lesson);
      break;

    // ── Koch session started / stopped ──
    case 'koch_session':
      kochActive    = !!msg.started;
      currentLesson = msg.lesson || currentLesson;
      currentWpm    = msg.wpm || currentWpm;
      if (msg.started) {
        kochPaused = false;
        sessionCorrect = 0;
        sessionTotal   = 0;
        streak         = 0;
        charTrack      = {};
        updateScorebar();
        setDisplayWaiting();
        logEvent('Session started — Lesson ' + currentLesson + ' at ' + currentWpm + ' WPM');
      } else {
        kochPaused = false;
        inputEnabled = false;
        setCharBtnsEnabled(false);
        elDisplayChar.textContent = '—';
        elDisplayChar.className = 'display-char';
        elDisplayMorse.innerHTML = '&nbsp;';
        elDisplayMsg.textContent = 'Session ended.';
        logEvent('Session ended — ' + sessionCorrect + '/' + sessionTotal);
        fetchServerStats();
      }
      updateWpmDisplay();
      updateLessonDisplay();
      updateControlButtons();
      break;

    // ── Koch challenge: prepare audio, then ACK "ready" ──
    case 'koch_challenge':
      currentLesson = msg.lesson || currentLesson;
      updateLessonDisplay();
      setDisplayWaiting();
      inputEnabled = false;
      setCharBtnsEnabled(false);
      elDisplayMsg.textContent = 'Listen…';
      // Build the audio sequence but do NOT play yet — wait for "go"
      if (msg.pattern && msg.ditMs) {
        lastPattern = msg.pattern;
        lastDitMs   = msg.ditMs;
        pendingSeq  = buildMorseSeq(msg.pattern, msg.ditMs);
        elBtnReplay.disabled = false;
        // Tell the ESP32 we're ready to play
        wsSend({ type: 'koch_ready' });
      }
      break;

    // ── Koch go: ESP32 says play now (buzzer starts simultaneously) ──
    case 'koch_go':
      if (pendingSeq) {
        playPreparedSeq(pendingSeq);
        pendingSeq = null;
      }
      break;

    // ── Freeform WORD: prepare audio for one character, then ACK ──
    case 'word_char':
      if (msg.pattern && msg.ditMs) {
        lastPattern = msg.pattern;
        lastDitMs   = msg.ditMs;
        pendingSeq  = buildMorseSeq(msg.pattern, msg.ditMs);
        // Show the character and its pattern on screen
        elDisplayChar.textContent = msg.char || '';
        elDisplayChar.className = 'display-char';
        elDisplayMorse.textContent = msg.pattern;
        // Tell the ESP32 we're ready
        wsSend({ type: 'word_ready' });
      }
      break;

    // ── Freeform WORD go: ESP32 says play now ──
    case 'word_go':
      if (pendingSeq) {
        playPreparedSeq(pendingSeq);
        pendingSeq = null;
      }
      break;

    // ── A character finished playing ──
    case 'char_sent':
      if (kochActive) {
        // In Koch mode, this means playback finished — enable input
        inputEnabled = true;
        setCharBtnsEnabled(true);
        elDisplayMsg.textContent = 'What did you hear?';
        // Pattern was already stored from koch_challenge; update from
        // char_sent only as a fallback (e.g. reconnect mid-playback)
        if (msg.morse && !lastPattern) {
          lastPattern = msg.morse;
          lastDitMs = 1200 / currentWpm;
        }
        elBtnReplay.disabled = false;
      }
      break;

    // ── Koch answer result ──
    case 'koch_result':
      inputEnabled = false;
      setCharBtnsEnabled(false);
      sessionCorrect = msg.session_correct;
      sessionTotal   = msg.session_total;
      currentLesson  = msg.lesson || currentLesson;
      if (msg.correct) {
        streak++;
        showResult(msg.expected, true, msg.reaction_ms);
      } else {
        streak = 0;
        showResult(msg.expected, false, msg.reaction_ms, msg.received);
      }
      updateScorebar();
      updateLessonDisplay();
      flashCharBtn(msg.expected, msg.correct);
      if (!msg.correct && msg.received) {
        flashCharBtn(msg.received, false);
      }
      logResult(msg);
      break;

    // ── Koch generic event (lesson advance, speed change text) ──
    case 'koch_event':
      elDisplayMsg.textContent = msg.message || '';
      logEvent(msg.message || '');
      break;

    // ── Speed change ──
    case 'speed_change':
      currentWpm = msg.wpm || currentWpm;
      updateWpmDisplay();
      break;

    // ── Playback messages (non-Koch freeform sending) ──
    case 'playback_start':
      elDisplayMsg.textContent = 'Sending: ' + (msg.message || '');
      break;
    case 'playback_done':
      if (!kochActive) {
        elDisplayMsg.textContent = 'Done.';
      }
      break;

    // ── Pong (latency test) ──
    case 'pong':
      logEvent('Pong — uptime ' + msg.uptime_ms + 'ms');
      break;

    // ── Buzzer mute state ──
    case 'buzzer_state':
      buzzerEnabled = !!msg.enabled;
      updateBuzzerButton();
      break;

    // ── Koch pause / resume ──
    case 'koch_pause':
      kochPaused = !!msg.paused;
      if (kochPaused) {
        inputEnabled = false;
        setCharBtnsEnabled(false);
        pendingSeq = null;
        elDisplayMsg.textContent = 'Paused.';
        logEvent('Session paused');
      } else {
        elDisplayMsg.textContent = 'Resumed — listen…';
        logEvent('Session resumed');
      }
      updateControlButtons();
      break;

    default:
      break;
  }
}

// ── Display Helpers ─────────────────────────────────────────
function setDisplayWaiting() {
  elDisplayChar.textContent = '?';
  elDisplayChar.className = 'display-char waiting';
  elDisplayMorse.innerHTML = '&nbsp;';
}

function showResult(expected, correct, reactionMs, received) {
  elDisplayChar.textContent = expected;
  elDisplayChar.className = 'display-char ' + (correct ? 'correct' : 'wrong');
  elDisplayMsg.textContent = correct
    ? '✓ Correct  (' + reactionMs + 'ms)'
    : '✗ Wrong — was ' + expected + ', you sent ' + (received || '?') + '  (' + reactionMs + 'ms)';

  if (lastPattern) {
    elDisplayMorse.textContent = lastPattern;
  }
}

function updateScorebar() {
  elScoreCorrect.textContent = sessionCorrect;
  elScoreTotal.textContent   = sessionTotal;
  if (sessionTotal > 0) {
    elScorePct.textContent = Math.round(100 * sessionCorrect / sessionTotal) + '%';
  } else {
    elScorePct.textContent = '—';
  }
  elScoreStreak.textContent = '🔥 ' + streak;
}

function updateWpmDisplay() {
  elSpeedDisplay.textContent = currentWpm;
  elHeaderWpm.textContent    = currentWpm + ' WPM';
}

function updateLessonDisplay() {
  elHeaderLesson.textContent = 'Lesson ' + currentLesson;
}

function updateControlButtons() {
  elBtnStart.disabled = kochActive;
  elBtnStop.disabled  = !kochActive;
  elBtnPause.disabled = !kochActive;
  if (elBtnReset) { elBtnReset.disabled = kochActive; }
  if (kochPaused) {
    elBtnPause.textContent = '▶ Resume';
    elBtnPause.classList.add('resuming');
  } else {
    elBtnPause.textContent = '⏸ Pause';
    elBtnPause.classList.remove('resuming');
  }
}

// ── Character Grid ──────────────────────────────────────────

function applyKochChars(chars, lesson) {
  if (!Array.isArray(chars) || chars.length === 0) return;
  activeKochChars = chars;
  if (lesson) currentLesson = lesson;
  buildCharGrid();
}

function buildCharGrid() {
  if (!elCharGrid) return;
  elCharGrid.innerHTML = '';

  if (activeKochChars.length === 0) {
    buildCharGridFallback();
    return;
  }

  for (var i = 0; i < activeKochChars.length; i++) {
    var entry = activeKochChars[i];
    var btn = document.createElement('button');
    btn.className = 'char-btn';
    btn.textContent = entry.display;
    btn.setAttribute('data-char', entry.ch);
    btn.disabled = !inputEnabled;
    btn.addEventListener('click', onCharBtnClick);
    elCharGrid.appendChild(btn);
  }
}

function buildCharGridFallback() {
  if (!elCharGrid) return;
  elCharGrid.innerHTML = '';

  var count = currentLesson;
  var maxCount = KOCH_ORDER_FALLBACK.length + KOCH_PROSIGNS_FALLBACK.length;
  if (count > maxCount) count = maxCount;

  for (var i = 0; i < count; i++) {
    var ch, display;
    if (i < KOCH_ORDER_FALLBACK.length) {
      ch = KOCH_ORDER_FALLBACK[i];
      display = ch;
    } else {
      var pi = i - KOCH_ORDER_FALLBACK.length;
      if (pi < KOCH_PROSIGNS_FALLBACK.length) {
        ch = KOCH_PROSIGNS_FALLBACK[pi].ch;
        display = KOCH_PROSIGNS_FALLBACK[pi].display;
      } else {
        break;
      }
    }
    var btn = document.createElement('button');
    btn.className = 'char-btn';
    btn.textContent = display;
    btn.setAttribute('data-char', ch);
    btn.disabled = !inputEnabled;
    btn.addEventListener('click', onCharBtnClick);
    elCharGrid.appendChild(btn);
  }
}

function onCharBtnClick(e) {
  if (!inputEnabled) return;
  var ch = e.currentTarget.getAttribute('data-char');
  if (!ch) return;
  inputEnabled = false;
  setCharBtnsEnabled(false);
  wsSend({ type: 'koch_answer', char: ch });
}

function setCharBtnsEnabled(enabled) {
  var btns = elCharGrid.querySelectorAll('.char-btn');
  for (var i = 0; i < btns.length; i++) {
    btns[i].disabled = !enabled;
  }
}

function flashCharBtn(ch, correct) {
  ch = ch.toUpperCase();
  var btns = elCharGrid.querySelectorAll('.char-btn');
  for (var i = 0; i < btns.length; i++) {
    var btnChar = btns[i].getAttribute('data-char');
    if (btnChar === ch || btns[i].textContent === ch) {
      btns[i].classList.add(correct ? 'correct' : 'incorrect');
      (function (b) {
        setTimeout(function () {
          b.classList.remove('correct', 'incorrect');
        }, 900);
      })(btns[i]);
    }
  }
}

// ── Commands ────────────────────────────────────────────────
function cmdKochStart() {
  unlockAudio();
  wsSend({ type: 'command', cmd: 'koch start' });
}

function cmdKochStop() {
  pendingSeq = null;
  wsSend({ type: 'koch_stop' });
}

function cmdKochPause() {
  if (kochPaused) {
    wsSend({ type: 'koch_resume' });
  } else {
    wsSend({ type: 'koch_pause' });
  }
}

function cmdReplay() {
  unlockAudio();
  if (lastPattern && lastDitMs > 0) {
    playMorseTone(lastPattern, lastDitMs);
  }
}

function cmdKochReset() {
  if (!confirm('Reset ALL Koch progress?\n\nThis clears your lesson, speed, and all character statistics.')) {
    return;
  }
  wsSend({ type: 'koch_reset' });
  sessionCorrect = 0;
  sessionTotal   = 0;
  streak         = 0;
  charTrack      = {};
  serverStats    = null;
  currentLesson  = 2;
  currentWpm     = 20;
  lastPattern    = '';
  pendingSeq     = null;
  updateScorebar();
  updateWpmDisplay();
  updateLessonDisplay();
  renderStatsPanel();
  elDisplayChar.textContent = '—';
  elDisplayChar.className = 'display-char';
  elDisplayMorse.innerHTML = '&nbsp;';
  elDisplayMsg.textContent = 'Progress reset.';
  logEvent('All Koch progress reset to defaults');
  setTimeout(fetchServerStats, 500);
}

function cmdSpeed(delta) {
  var newWpm = currentWpm + delta;
  if (newWpm < 1) newWpm = 1;
  if (newWpm > 60) newWpm = 60;
  wsSend({ type: 'set_wpm', wpm: newWpm });
}

function cmdBuzzerToggle() {
  buzzerEnabled = !buzzerEnabled;
  wsSend({ type: 'set_buzzer', enabled: buzzerEnabled ? 'true' : 'false' });
  updateBuzzerButton();
}

function updateBuzzerButton() {
  if (!elBtnBuzzer) return;
  if (buzzerEnabled) {
    elBtnBuzzer.textContent = '🔔 Buzzer';
    elBtnBuzzer.classList.remove('muted');
  } else {
    elBtnBuzzer.textContent = '🔕 Muted';
    elBtnBuzzer.classList.add('muted');
  }
}

// ── Web Audio API ───────────────────────────────────────────
var audioCtx      = null;
var gainNode      = null;
var toneFreq      = 700;
var audioUnlocked = false;
var lastToneEndMs = 0;

var AUDIO_IDLE_THRESHOLD = 1500;
var AUDIO_PRIMER_MS      = 150;

function initAudio() {
  if (audioCtx) return true;
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    audioCtx = new AC();
    gainNode = audioCtx.createGain();
    gainNode.gain.value = 0.5;
    gainNode.connect(audioCtx.destination);
    return true;
  } catch (e) {
    return false;
  }
}

function unlockAudio() {
  if (!initAudio()) return;
  try { audioCtx.resume(); } catch (e) { /* best effort */ }
  if (!audioUnlocked) {
    try {
      var silent = audioCtx.createOscillator();
      var silentGain = audioCtx.createGain();
      silentGain.gain.value = 0;
      silent.connect(silentGain);
      silentGain.connect(audioCtx.destination);
      silent.start();
      silent.stop(audioCtx.currentTime + 0.001);
      audioUnlocked = true;
    } catch (e) { /* best effort */ }
  }
}

// Build a sequence of tone/silence steps from a morse pattern string.
// Returns an array of { tone: bool, ms: number, silent?: bool }.
function buildMorseSeq(pattern, ditMs) {
  var seq = [];
  for (var i = 0; i < pattern.length; i++) {
    var el = pattern[i];
    if (el === '.' || el === '-') {
      seq.push({ tone: true,  ms: (el === '.') ? ditMs : ditMs * 3 });
      seq.push({ tone: false, ms: ditMs });
    } else if (el === ' ') {
      seq.push({ tone: false, ms: ditMs * 2 });
    }
  }

  // If audio has been idle, prepend a silent primer to wake hardware
  var now = Date.now();
  if (now - lastToneEndMs > AUDIO_IDLE_THRESHOLD) {
    seq.unshift({ tone: false, ms: 20 });
    seq.unshift({ tone: true,  ms: AUDIO_PRIMER_MS, silent: true });
  }
  return seq;
}

// Play a pre-built sequence immediately (called on "koch_go" / "word_go").
function playPreparedSeq(seq) {
  if (!initAudio()) return;
  if (!seq || seq.length === 0) return;

  if (audioCtx.state !== 'running') {
    try {
      var p = audioCtx.resume();
      if (p && typeof p.then === 'function') {
        p.then(function () { playSequence(seq); });
      } else {
        setTimeout(function () { playSequence(seq); }, 60);
      }
    } catch (e) {
      setTimeout(function () { playSequence(seq); }, 60);
    }
    return;
  }
  playSequence(seq);
}

// Play morse for replay / test tone (builds and plays immediately).
function playMorseTone(pattern, ditMs) {
  var seq = buildMorseSeq(pattern, ditMs);
  if (seq.length === 0) return;
  playPreparedSeq(seq);
}

function playSequence(seq) {
  var idx = 0;
  function next() {
    if (idx >= seq.length) {
      lastToneEndMs = Date.now();
      return;
    }
    var step = seq[idx++];
    if (step.tone) {
      var osc = audioCtx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = toneFreq;
      if (step.silent) {
        var muteGain = audioCtx.createGain();
        muteGain.gain.value = 0;
        osc.connect(muteGain);
        muteGain.connect(audioCtx.destination);
      } else {
        osc.connect(gainNode);
      }
      osc.start();
      setTimeout(function () {
        try { osc.stop(); } catch (e) { /* already stopped */ }
        next();
      }, step.ms);
    } else {
      setTimeout(next, step.ms);
    }
  }
  next();
}

function testTone() {
  unlockAudio();
  playMorseTone('-.-', 1200 / currentWpm);
}

function setVolume(val) {
  if (!initAudio()) return;
  gainNode.gain.value = val / 100;
}

// ── Stats Panel ─────────────────────────────────────────────

function fetchServerStats() {
  fetch('/api/koch_stats')
    .then(function (res) { return res.json(); })
    .then(function (data) {
      serverStats = data;
      renderStatsPanel();
    })
    .catch(function () {
      renderStatsPanel();
    });
}

function renderStatsPanel() {
  if (!elStatsBody) return;

  if (!serverStats && sessionTotal === 0) {
    elStatsBody.innerHTML = '<p class="stats-placeholder">Start a session to see stats.</p>';
    return;
  }

  var html = '';

  if (sessionTotal > 0) {
    var pct = Math.round(100 * sessionCorrect / sessionTotal);
    html += '<p>Session: <b>' + sessionCorrect + '/' + sessionTotal +
            '</b> (' + pct + '%) — Streak: <b>' + streak + '</b></p>';
  }

  if (serverStats && serverStats.chars && serverStats.chars.length > 0) {
    html += '<h4 style="margin:8px 0 4px;color:#f39c12;">All-Time Stats (Server)</h4>';

    var weakest = [];
    for (var w = 0; w < serverStats.chars.length; w++) {
      var sw = serverStats.chars[w];
      if (sw.sent >= 3) {
        var wa = Math.round(100 * sw.correct / sw.sent);
        if (wa < 70) weakest.push(sw.display);
      }
    }
    if (weakest.length > 0) {
      html += '<p style="color:#e74c3c;">⚠ Weakest: <b>' + weakest.join(', ') + '</b></p>';
    }

    html += '<table class="stats-table">';
    html += '<tr><th>Ch</th><th>Sent</th><th>Correct</th><th>Acc</th><th>Avg ms</th><th>Wt</th></tr>';

    var sorted = serverStats.chars.slice().sort(function (a, b) {
      if (a.sent === 0 && b.sent === 0) return 0;
      if (a.sent === 0) return 1;
      if (b.sent === 0) return -1;
      return (a.correct / a.sent) - (b.correct / b.sent);
    });

    for (var i = 0; i < sorted.length; i++) {
      var e = sorted[i];
      var acc = e.sent > 0 ? Math.round(100 * e.correct / e.sent) : 0;
      var cls = '';
      if (e.sent > 0) {
        cls = acc < 70 ? 'weak' : (acc >= 90 ? 'strong' : '');
      }
      html += '<tr class="' + cls + '">';
      html += '<td>' + e.display + '</td>';
      html += '<td>' + e.sent + '</td>';
      html += '<td>' + e.correct + '</td>';
      html += '<td>' + (e.sent > 0 ? acc + '%' : '—') + '</td>';
      html += '<td>' + (e.sent > 0 ? e.avg_ms : '—') + '</td>';
      html += '<td>' + e.prob + '</td>';
      html += '</tr>';
    }
    html += '</table>';
  }

  if (charTrack && Object.keys(charTrack).length > 0) {
    html += '<h4 style="margin:8px 0 4px;color:#2ecc71;">This Session (Local)</h4>';
    html += '<table class="stats-table"><tr><th>Ch</th><th>Sent</th><th>Correct</th><th>Acc</th><th>Avg ms</th></tr>';
    var entries = [];
    for (var ch in charTrack) {
      if (charTrack.hasOwnProperty(ch)) entries.push(charTrack[ch]);
    }
    entries.sort(function (a, b) {
      var accA = a.sent > 0 ? a.correct / a.sent : 1;
      var accB = b.sent > 0 ? b.correct / b.sent : 1;
      return accA - accB;
    });
    for (var j = 0; j < entries.length; j++) {
      var le = entries[j];
      var lacc = le.sent > 0 ? Math.round(100 * le.correct / le.sent) : 0;
      var lavg = le.sent > 0 ? Math.round(le.totalMs / le.sent) : 0;
      var lcls = lacc < 70 ? 'weak' : (lacc >= 90 ? 'strong' : '');
      html += '<tr class="' + lcls + '"><td>' + le.display + '</td><td>' + le.sent +
              '</td><td>' + le.correct + '</td><td>' + lacc + '%</td><td>' + lavg + '</td></tr>';
    }
    html += '</table>';
  }

  elStatsBody.innerHTML = html;
}

function updateStatsPanel() {
  renderStatsPanel();
}

var charTrack = {};

function trackCharResult(msg) {
  var ch = msg.expected;
  if (!ch) return;
  if (!charTrack[ch]) {
    charTrack[ch] = { ch: ch, display: ch, sent: 0, correct: 0, totalMs: 0 };
  }
  charTrack[ch].sent++;
  if (msg.correct) charTrack[ch].correct++;
  charTrack[ch].totalMs += (msg.reaction_ms || 0);
}

// ── Event Log ───────────────────────────────────────────────
var MAX_LOG = 80;

function logResult(msg) {
  trackCharResult(msg);
  updateStatsPanel();
  var cls = msg.correct ? 'correct' : 'wrong';
  var text = msg.correct
    ? '✓ ' + msg.expected + ' (' + msg.reaction_ms + 'ms)'
    : '✗ expected ' + msg.expected + ', got ' + (msg.received || '?') + ' (' + msg.reaction_ms + 'ms)';
  addLogEntry(text, cls);
}

function logEvent(text) {
  addLogEntry(text, 'event');
}

function addLogEntry(text, cls) {
  if (!elLogBody) return;
  var div = document.createElement('div');
  div.className = 'log-entry ' + (cls || '');
  div.textContent = text;
  elLogBody.insertBefore(div, elLogBody.firstChild);
  while (elLogBody.children.length > MAX_LOG) {
    elLogBody.removeChild(elLogBody.lastChild);
  }
}

// ── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
  cacheDom();
  buildCharGrid();
  updateScorebar();
  updateWpmDisplay();
  updateLessonDisplay();
  updateBuzzerButton();
  updateControlButtons();
  connect();
  fetchServerStats();
});