#include "MorseWebSocket.h"
#include "MorseLookup.h"
#include "MorsePlayback.h"
#include "MorseCommands.h"
#include "MorseWebServer.h"
#include "KochTrainer.h"
#include "WiFiAP.h"
#include "Storage.h"
#include "config.h"

// --- Pin definitions (declared extern in MorsePlayback.h and WiFiAP.h) ---
const unsigned int LED_PIN = 2;
const unsigned int BUZZER_PIN = 25;
const unsigned int LED_GREEN_PIN = 4;
const unsigned int LED_RED_PIN = 17;
const int PWM_DUTY_CYCLE = 128;

// --- RNG seed pin (floating ADC for entropy) ---
// GPIO36 (SVP) is input-only and safe for analogRead.
// Do NOT use GPIO3 — it is U0RXD (serial receive).
static const int RAND_PIN = 36;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n======================================");
  Serial.println("   ESP32 Morse Code Trainer");
  Serial.println("======================================\n");

  // Seed the random number generator from a floating ADC pin
  randomSeed(analogRead(RAND_PIN));

  // Initialize hardware pins
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(LED_GREEN_PIN, OUTPUT);
  digitalWrite(LED_GREEN_PIN, LOW);

  pinMode(LED_RED_PIN, OUTPUT);
  digitalWrite(LED_RED_PIN, LOW);

  // Configure buzzer PWM using LEDC
  ledcAttach(BUZZER_PIN, 800, 8);  // 800 Hz tone, 8-bit resolution
  ledcWrite(BUZZER_PIN, 0);

  // Initialize Morse code lookup table
  initializeVectorTable();

  // Initialize NVS storage (must be before anything that loads state)
  initStorage();

  // Initialize Koch trainer (loads lesson + charStats + WPM from NVS)
  initKochTrainer();

  // Update timing from loaded WPM
  updateTiming();

  // Restore buzzer mute state from NVS
  setBuzzerEnabled(loadBuzzerFromNVS());

  // Start WiFi Access Point
  initWiFiAP();

  // Start web server (includes WebSocket)
  initWebServer();

  Serial.println("Ready! Type 'help' for commands.\n");
  Serial.print("> ");
}

void loop() {
  // Process serial commands
  readSerialInput();

  // Update non-blocking Morse playback state machine
  updatePlayback();

  // Update Koch trainer state machine (no-op when idle)
  updateKochTrainer();

  // Monitor WiFi client connections
  checkWiFiClients();
  blinkLEDForConnection();

  // Handle web server (WebSocket cleanup)
  handleWebServer();
}