#ifndef MORSELOOKUP_H
#define MORSELOOKUP_H

#include <Arduino.h>
#include <vector>

// Mode selection using enum class
enum class MorseMode : uint8_t {
  Koch,        // Koch trainer (adaptive CW practice)
  Vector,      // Use vector-based table (dynamic)
  Progmem,     // Use PROGMEM binary tree
  Progtable    // Use PROGMEM direct lookup table
};

// Morse code class definition
class MorseMap {
private:
  char ch;
  String code;
  
public:
  MorseMap(char character = '\0', const String &morseCode = "")
    : ch(character), code(morseCode) {}
  
  char getCharacter() const { return ch; }
  String getCode() const { return code; }
};

// Global variables
extern MorseMode currentMode;
extern std::vector<MorseMap> morseTable;

// Lookup functions
String getMorseCode(char c);
String charToMorse(char c);
String lookupMorse(char c);
String lookupMorseProgTable(char c);
String preprocessProsigns(String message);

// Table management
void initializeVectorTable();
void addMorseEntry(char character, const String &code);

// Helper functions
bool searchSubtree(int index, char target, int level);

#endif